﻿//Grading Id: W1498
//Program 4
//Due date: 4-24-18
// Course Section: CIS-199-01
//This program uses 2 classes and combines them to make a ground package
// program that has numbers for packages and does the math to set the price.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{

    class program
    {
        static void Main(string[] args)
        {
            // Create 5 objects for the GroundPackage class to enter
            GroundPackage package1 = new GroundPackage(40218, 54321, 15, 30, 60, 20);
            GroundPackage package2 = new GroundPackage(40220, 87625, 10, 20, 30, 40);
            GroundPackage package3 = new GroundPackage(12345, 54321, 18, 36, 7, 187);
            GroundPackage package4 = new GroundPackage(13281, 46666, 71, 54, 36, 90);
            GroundPackage package5 = new GroundPackage(18956, 99759, 99.5, 73.8, 62, 125);

            // array for packages that store the above arrays 
            GroundPackage[] packages = { package1, package2, package3, package4, package5 };

            //display's the packages
            DisplayPackages(packages);
        }

        static void DisplayPackages(GroundPackage[] packages)
        {

            //helps set up the print for the packages. 
            for (int i = 0; i < packages.Length; i++)
            {
                Console.WriteLine("Package " + (i + 1));
                Console.WriteLine(packages[i]);
                Console.WriteLine($"{"Shipping Cost"}: ${ packages[i].CalcCost()}");
                Console.WriteLine();
            }
        }

    }

    class GroundPackage
    {
        private int originZip;// sets origin zip to a int 
        private int destinatonZip; // sets destinatio zip to a int
        private double length; //sets length to a double 
        private double width; // sets length to a double
        private double height;// sets length to a double
        private double weight;//sets length to a double.

        // uses constructor's to name each property
        // than uses the properties and makes sure they are all valid
        public GroundPackage(int originZip, int destZip, double length, double width, double height, double weight)
        {
            OriginZip = originZip;
            DestinatonZip = destZip;
            Length = length;
            Height = height;
            Width = width;
            Weight = weight;

        }

        // creates the properties and makes sure they are a certain number 
        //using if else statements. 
        //preconditon: origin zip code must be set between 00000 or 99999
        //postcondtion: keeps it if valid, sets it to 40202 if it is not valid. 
        public int OriginZip
        {
            get { return originZip; }
            set
            {
                // if the origin ziocode is not between these two numbers, 
                // it will set it to 40202
                if (value >= 00000 && value <= 99999)
                    originZip = value;
                else
                    originZip = 40202;
            }
        }
        //preconditon: destination zip code must be set between 00000 or 99999
        //postcondtion: keeps it if valid, sets it to 90210 if it is not valid.  
        public int DestinatonZip
        {
            get { return destinatonZip; }
            set
            {
                // if the destination zipzode is not between the two numbers, 
                // it will set it to 90210
                if (value >= 00000 && value <= 99999)
                    destinatonZip = value;
                else
                    destinatonZip = 90210;
            }
        }
        //preconditon: length must be set at greater than 0 
        //postcondtion: keeps it if valid, sets it to 1 if it is not valid. 
        public double Length
        {
            get { return length; }
            set
            {
                // checks to see if the length is greater than 0, 
                //if not it sets it to 1
                if (value > 0)
                    length = value;
                else
                    length = 1.0;
            }
        }
        //preconditon: width must be set at greater than 0 
        //postcondtion: keeps it if valid, sets it to 1 if it is not valid. 
        public double Width
        {
            get { return width; }
            set
            {
                // checks to see if the width is greater than 0, 
                // if not it sets it to 1
                if (value > 0)
                    width = value;
                else
                    width = 1.0;
            }
        }
        //preconditon: length must be set at greater than 0 
        //postcondtion: keeps it if valid, sets it to 1 if it is not valid. 
        public double Height
        {
            get { return height; }
            set
            {
                // checks to see if the height is greater than 0,
                // if it is not it sets it to 1
                if (value > 0)
                    height = value;
                else
                    height = 1.0;
            }
        }
        //preconditon: length must be set at greater than 0 
        //postcondtion: keeps it if valid, sets it to 1 if it is not valid. 
        public double Weight
        {
            get { return weight; }
            set
            {
                // checks to see if the weight is greater than 0 
                // if it isnt it sets it to 1
                if (value > 0)
                    weight = value;
                else
                    weight = 1.0;
            }
        }
        //precondtion: takes the origin zip code and destination zipcode and divides them by 10000 to get a 1 digit number
        //postcondtion: MAth.Abs makes sure it stays positve and feeds it into the CalcCost equation. 
        public int ZoneDistance
        {
            get
            {
                //divides the origin zipcode and destination zip code 
                //by 10000 to get the first number and makes that the distance.
                int Zipcode1 = OriginZip / 10000;
                int Zipcode2 = DestinatonZip / 10000;
                return Math.Abs(Zipcode1 - Zipcode2);
                //math.Abs makes sure the outcome is always positive so the cost
                // doesnt come out to be a negative.
            }
        }

        public override string ToString()
        {
            //accepts no parameters and returns a string. uses override and 
            //Environment.NewLine to skip to the next line 
            return $"{"Origin ZipCode"}: {OriginZip}" + Environment.NewLine +
            $"{"Destination ZipCode"}: {DestinatonZip}" + Environment.NewLine +
            $"{"Length"}: {Length}" + Environment.NewLine +
            $"{"Height"}: {Height}" + Environment.NewLine +
            $"{"Width"}: {Width}" + Environment.NewLine +
            $"{"Weight"}: {Weight}";
        }

        public double CalcCost()
        {
            // Calculate's the cost and returns the cost 
            double cost = .20 * (Length + Width + Height) + .5 * (ZoneDistance + 1) * (Weight);
            return cost;
        }
    }
}

       