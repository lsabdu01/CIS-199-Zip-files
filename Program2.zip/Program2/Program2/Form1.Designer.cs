﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LastNameLBL = new System.Windows.Forms.Label();
            this.CreditHoursLBL = new System.Windows.Forms.Label();
            this.LastNameTXT = new System.Windows.Forms.TextBox();
            this.HoursTXT = new System.Windows.Forms.TextBox();
            this.DayTimeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LastNameLBL
            // 
            this.LastNameLBL.AutoSize = true;
            this.LastNameLBL.Location = new System.Drawing.Point(31, 62);
            this.LastNameLBL.Name = "LastNameLBL";
            this.LastNameLBL.Size = new System.Drawing.Size(153, 13);
            this.LastNameLBL.TabIndex = 0;
            this.LastNameLBL.Text = "Enter First Letter of Last Name:";
            // 
            // CreditHoursLBL
            // 
            this.CreditHoursLBL.AutoSize = true;
            this.CreditHoursLBL.Location = new System.Drawing.Point(88, 19);
            this.CreditHoursLBL.Name = "CreditHoursLBL";
            this.CreditHoursLBL.Size = new System.Drawing.Size(96, 13);
            this.CreditHoursLBL.TabIndex = 1;
            this.CreditHoursLBL.Text = "Enter Credit Hours:";
            this.CreditHoursLBL.Click += new System.EventHandler(this.label2_Click);
            // 
            // LastNameTXT
            // 
            this.LastNameTXT.Location = new System.Drawing.Point(190, 59);
            this.LastNameTXT.Name = "LastNameTXT";
            this.LastNameTXT.Size = new System.Drawing.Size(100, 20);
            this.LastNameTXT.TabIndex = 2;
            // 
            // HoursTXT
            // 
            this.HoursTXT.Location = new System.Drawing.Point(190, 16);
            this.HoursTXT.Name = "HoursTXT";
            this.HoursTXT.Size = new System.Drawing.Size(100, 20);
            this.HoursTXT.TabIndex = 3;
            // 
            // DayTimeButton
            // 
            this.DayTimeButton.Location = new System.Drawing.Point(164, 125);
            this.DayTimeButton.Name = "DayTimeButton";
            this.DayTimeButton.Size = new System.Drawing.Size(75, 23);
            this.DayTimeButton.TabIndex = 5;
            this.DayTimeButton.Text = "Day/Time";
            this.DayTimeButton.UseVisualStyleBackColor = true;
            this.DayTimeButton.Click += new System.EventHandler(this.DayTimeButton_Click);
            // 
            // Program2
            // 
            this.AcceptButton = this.DayTimeButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 294);
            this.Controls.Add(this.DayTimeButton);
            this.Controls.Add(this.HoursTXT);
            this.Controls.Add(this.LastNameTXT);
            this.Controls.Add(this.CreditHoursLBL);
            this.Controls.Add(this.LastNameLBL);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LastNameLBL;
        private System.Windows.Forms.Label CreditHoursLBL;
        private System.Windows.Forms.TextBox LastNameTXT;
        private System.Windows.Forms.TextBox HoursTXT;
        private System.Windows.Forms.Button DayTimeButton;
    }
}

