﻿// w1498
//Program 2
//3/8/18
//CIS-199-01
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void DayTimeButton_Click(object sender, EventArgs e)
        {
            int CreditHours; //Credit hours variables
            const int JUNIOR = 60; //Min Junior credit hours
            const int SENIOR = 90; // min senior credit hours 
            const int SOPHMORE = 30; //min sophmore credit hours 
            char LetterLastName; // Letter last name

            //assigns credit hours to what is entered into text box 
            if (int.TryParse(HoursTXT.Text, out CreditHours))
                // assigns letter last name to what is entered
                if (char.TryParse(LastNameTXT.Text, out LetterLastName))

                {// starts seniors 
                    if (CreditHours >= SENIOR)
                        if (LetterLastName <= 'd')
                            MessageBox.Show("Wednesday March 28th at 8:30");
                   
                    else if (LetterLastName <= 'i')
                        MessageBox.Show("Wednesday March 28th at 10:00");
                    else if (LetterLastName <= 'o')
                        MessageBox.Show("Wednesday March 28th at 11:30");
                    else if (LetterLastName <= 's')
                        MessageBox.Show("Wednesday March 28th at 2:00");
                    else
                        MessageBox.Show("Wednesday March 28th at 4:00");

                    //starts juniors 
                    else if (CreditHours >= JUNIOR)
                        if (LetterLastName <= 'd')
                            MessageBox.Show("Thursday March 29th at 8:30");
                        else if (LetterLastName <= 'i')
                            MessageBox.Show("Thursday March 29th at 10:00");
                        else if (LetterLastName <= 'o')
                            MessageBox.Show("Thursday March 29th at 11:30");
                        else if (LetterLastName <= 's')
                            MessageBox.Show("Thursday March 29th at 2:00");
                        else
                            MessageBox.Show("Thurdsay March 29th at 4:00");

                    //starts sophomore
                    else if (CreditHours >= SOPHMORE)
                        if (LetterLastName <= 'b')
                            MessageBox.Show("Friday March 30th at 8:30");
                        else if (LetterLastName <= 'd')
                            MessageBox.Show("Friday March 30th at 10:00");
                        else if (LetterLastName <= 'f')
                            MessageBox.Show("Friday March 30th at 11:30");
                        else if (LetterLastName <= 'i')
                            MessageBox.Show("Friday March 30th at 2:00");
                        else if (LetterLastName <= 'l')
                            MessageBox.Show("Friday March 30th at 4:00");
                        else if (LetterLastName <= 'o')
                            MessageBox.Show("Monday April 2nd at 8:30");
                        else if (LetterLastName <= 'q')
                            MessageBox.Show("Monday April 2nd at 10:00");
                        else if (LetterLastName <= 's')
                            MessageBox.Show("Monday April 2nd at 11:30");
                        else if (LetterLastName <= 'v')
                            MessageBox.Show("Monday April 2nd at 2:00");
                        else
                            MessageBox.Show("Monday April 2nd at 4:00");
                    // starts freshman 
                    else
                        if (LetterLastName <= 'b')
                        MessageBox.Show("Tuesday April 3rd at 8:30");
                    else if (LetterLastName <= 'd')
                        MessageBox.Show("Tuesday April 3rd at 10:00");
                    else if (LetterLastName <= 'f')
                        MessageBox.Show("Tuesday April 3rd at 11:30");
                    else if (LetterLastName <= 'i')
                        MessageBox.Show("Tuesday April 3rd at 2:00");
                    else if (LetterLastName <= 'l')
                        MessageBox.Show("Tuesday April 3rd at 4:00");
                    else if (LetterLastName <= 'o')
                        MessageBox.Show("Wednesday April 4th at 8:30");
                    else if (LetterLastName <= 'q')
                        MessageBox.Show("Wednesday April 4th at 10:00");
                    else if (LetterLastName <= 's')
                        MessageBox.Show("Wednesday April 4th at 11:30");
                    else if (LetterLastName <= 'v')
                        MessageBox.Show("Wednesday April 4th at 2:00");
                    else
                        MessageBox.Show("Wednesday April 4th at 4:00");


                }   
                    
                }


        }
    }

